//To prepare the vegetable balls

Take all the veggies,finely chopped,in a bowl along with ginger,garlic,corn flour,maida,salt,black pepper and soya sauce
Mix them well,adding water as required for consistency
Make round balls out of thick vegetable mixture
Now deep fry the vegetable balls in a pan

//To prepare the manchurian sauce

Heat some oil in a pan and roast ginger,garlic,green chilli in it for a while
Add spring onion,tomato ketchup,chilli sauce,soya sauce and vinegar followed by salt and black pepper
Mix them well and add a mixture of corn flour plus water to the pan
Mix thoroughly and put the fried vegetable ball into the mixture
Properly mix the balls along with the sauce
Garnish with spring onion and celery. Serve hot along with cooked rice