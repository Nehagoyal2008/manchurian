//Ingredients for making vegetable  ball

1/2 cup Cabbage
1/2 cup Carrot
1/2 cup Capsicum
1/2 cup Spring Onion
1tsp Ginger
1tsp Garlic
3tbsp Corn Flour
2tbsp Maida
2tsp Salt
2tsp Black Pepper
1tsp Soya Sauce
1tbsp Water

//Ingredients for manchurian sauce

Oil
2tbsp Garlic
1tbsp Ginger
1tsp Green Chilli
2tbsp Chilli Sauce
1tsp Soya Sauce
1tsp Vinegar
1 1/2tbsp Salt
1tbsp Black Pepper
3tbsp Corn Flour
1 cup Water