A super delicious Indo-Chinese dish that will cater all your carvings and leave you want more!
This quick and easy dish is ideal for a party at home as well.
Check the ingredients and recipe file to make this delecious Indo-Chinese dish.
